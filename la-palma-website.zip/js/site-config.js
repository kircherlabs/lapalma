// La Palma site configuration
// Only replace values below with CONFIRMED operational details. Empty values are intentionally hidden.
window.LA_PALMA = {
  locationLabel: "Rosemary Beach, Florida",
  streetAddress: "",
  phone: "",
  email: "",
  reservationEmail: "",
  bookingUrl: "",
  hours: [],
  socials: { instagram: "", facebook: "", tiktok: "" },
  events: [
    // Example shape (remove the // only after the event is confirmed):
    // { date: "2026-10-23", title: "Dance Night", time: "8:00 PM" }
  ]
};
