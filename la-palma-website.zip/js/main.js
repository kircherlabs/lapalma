
(() => {
  const cfg = window.LA_PALMA || {};
  const q=(s,c=document)=>c.querySelector(s), qa=(s,c=document)=>[...c.querySelectorAll(s)];
  // Header + mobile nav
  const header=q('[data-header]'); const toggle=q('[data-nav-toggle]'); const nav=q('[data-nav]');
  const onScroll=()=>header&&header.classList.toggle('scrolled',scrollY>24); onScroll(); addEventListener('scroll',onScroll,{passive:true});
  if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open))});qa('a',nav).forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');toggle.setAttribute('aria-expanded','false')}));}
  // Reveal motion
  const reveals=qa('.reveal'); if('IntersectionObserver'in window){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}}),{threshold:.08});reveals.forEach(el=>io.observe(el));}else reveals.forEach(el=>el.classList.add('visible'));
  qa('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
  // Config-driven footer/contact
  qa('[data-location]').forEach(el=>el.textContent=cfg.streetAddress?`${cfg.streetAddress} · ${cfg.locationLabel||''}`:(cfg.locationLabel||'Location coming soon'));
  qa('[data-contact-value]').forEach(el=>el.textContent=cfg.phone||cfg.email||'To be confirmed');
  const contactStatus=q('[data-contact-status]'); if(contactStatus&&(cfg.phone||cfg.email)){contactStatus.textContent=[cfg.phone,cfg.email].filter(Boolean).join(' · ')}
  const socials=q('[data-social-links]'); if(socials){const names={instagram:'Instagram',facebook:'Facebook',tiktok:'TikTok'};Object.entries(cfg.socials||{}).filter(([,u])=>u).forEach(([k,u])=>{const a=document.createElement('a');a.href=u;a.target='_blank';a.rel='noopener';a.textContent=names[k]||k;socials.appendChild(a)});if(!socials.children.length) socials.innerHTML='<span class="muted">Social links coming soon.</span>';}
  // Venue plan toggle
  qa('[data-plan]').forEach(btn=>btn.addEventListener('click',()=>{qa('[data-plan]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const img=q('[data-plan-image]');if(img)img.src=`assets/images/venue-${btn.dataset.plan}.webp`}));
  // Lightbox
  const modal=q('[data-lightbox-modal]'), modalImg=q('[data-lightbox-image]');
  qa('[data-lightbox]').forEach(b=>b.addEventListener('click',()=>{if(!modal)return;modalImg.src=b.dataset.lightbox;modalImg.alt=b.dataset.alt||'';modal.classList.add('open');modal.setAttribute('aria-hidden','false')}));
  const closeLight=()=>{if(modal){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');modalImg.src=''}};q('[data-lightbox-close]')?.addEventListener('click',closeLight);modal?.addEventListener('click',e=>{if(e.target===modal)closeLight()});addEventListener('keydown',e=>{if(e.key==='Escape')closeLight()});
  // Event calendar
  const grid=q('[data-calendar-grid]'), monthEl=q('[data-cal-month]');
  if(grid&&monthEl){let cursor=new Date();cursor.setDate(1);const events=Array.isArray(cfg.events)?cfg.events:[];const render=()=>{grid.innerHTML='';monthEl.textContent=cursor.toLocaleDateString(undefined,{month:'long',year:'numeric'});const first=new Date(cursor.getFullYear(),cursor.getMonth(),1);const start=new Date(first);start.setDate(1-first.getDay());for(let i=0;i<42;i++){const d=new Date(start);d.setDate(start.getDate()+i);const cell=document.createElement('div');cell.className='calendar-day'+(d.getMonth()!==cursor.getMonth()?' outside':'');const iso=[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');const today=new Date();if(d.toDateString()===today.toDateString())cell.classList.add('today');cell.innerHTML=`<strong>${d.getDate()}</strong>`;events.filter(e=>e.date===iso).forEach(e=>{cell.classList.add('has-event');const s=document.createElement('span');s.className='calendar-event-dot';s.textContent=e.time?`${e.title} · ${e.time}`:e.title;cell.appendChild(s)});grid.appendChild(cell)}};render();q('[data-cal-prev]')?.addEventListener('click',()=>{cursor.setMonth(cursor.getMonth()-1);render()});q('[data-cal-next]')?.addEventListener('click',()=>{cursor.setMonth(cursor.getMonth()+1);render()});}
  // Reservation behavior. Never pretends to submit if no real destination is configured.
  const form=q('[data-reservation-form]');
  if(form){const status=q('[data-reservation-status]',form);const hasDestination=Boolean(cfg.bookingUrl||cfg.reservationEmail);if(!hasDestination){form.classList.add('disabled');qa('input,select,textarea,button',form).forEach(el=>el.disabled=true);status.classList.add('show');status.textContent='Online reservation requests are not live yet. Add a confirmed booking URL or reservation email in js/site-config.js before launch.';}else{form.addEventListener('submit',e=>{e.preventDefault();if(cfg.bookingUrl){location.href=cfg.bookingUrl;return;}const fd=new FormData(form);const subject=`La Palma reservation request — ${fd.get('date')} ${fd.get('time')}`;const body=[`Name: ${fd.get('firstName')} ${fd.get('lastName')}`,`Email: ${fd.get('email')}`,`Phone: ${fd.get('phone')||''}`,`Date: ${fd.get('date')}`,`Time: ${fd.get('time')}`,`Party: ${fd.get('partySize')}`,`Visit type: ${fd.get('visitType')}`,`Notes: ${fd.get('notes')||''}`].join('\n');location.href=`mailto:${encodeURIComponent(cfg.reservationEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;})}}
})();
